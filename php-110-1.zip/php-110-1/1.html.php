<html>
    <head><title>html+php</title></head>      
    <body>
        <?php echo "Hello world!"; ?> 
        <h1>html</h1>
        <?php echo "Hello world!"; ?> 
        <h1>html</h1>
        <?php echo "Hello world!"; ?> 
    </body>
</html>
