<?php 
    echo $_POST["id"];
    echo "<br>";
    echo $_POST["pwd"];
?>
