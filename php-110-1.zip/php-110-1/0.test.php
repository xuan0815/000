<?php 
phpinfo();
?>

